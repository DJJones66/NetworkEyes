import React, { useEffect, useState } from 'react';
import './ComponentNetworkStatus.css';

type Status = 'online' | 'offline' | 'unknown';

interface Target {
  name: string;
  url: string;
}

const targets: Target[] = [
  { name: 'Ollama', url: 'https://www.ollama.com' },
  { name: 'Local Ollama', url: 'http://localhost:11434' },
];

const ComponentNetworkStatus: React.FC = () => {
  const [statuses, setStatuses] = useState<Record<string, Status>>({
    Ollama: 'unknown',
    'Local Ollama': 'unknown'
  });

  const check = async (name: string, url: string) => {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 3000);
      await fetch(url, { method: 'GET', mode: 'no-cors', signal: controller.signal });
      clearTimeout(timer);
      setStatuses(prev => ({ ...prev, [name]: 'online' }));
    } catch {
      setStatuses(prev => ({ ...prev, [name]: 'offline' }));
    }
  };

  useEffect(() => {
    targets.forEach(t => check(t.name, t.url));
  }, []);

  return (
    <div className="bd-network-status">
      <h3>Network Status</h3>
      <ul>
        {targets.map(t => (
          <li key={t.name} className={`status ${statuses[t.name]}`}>
            <span className="indicator" />
            <span>{t.name}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ComponentNetworkStatus;
