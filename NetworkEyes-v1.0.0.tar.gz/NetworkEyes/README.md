# NetworkEyes Plugin

A BrainDrive plugin for network status monitoring and connectivity checking.

## Overview

NetworkEyes provides real-time network connectivity monitoring capabilities for BrainDrive services. It offers a comprehensive dashboard to track network status, connection health, and service availability.

## Features

- **Real-time Monitoring**: Continuous network status updates
- **Service Health Checks**: Monitor BrainDrive service connectivity
- **Visual Dashboard**: Intuitive network status display
- **Configurable Refresh**: Adjustable monitoring intervals
- **Detailed Statistics**: Comprehensive network metrics

## Installation

### From GitHub Releases

1. Go to the BrainDrive Plugin Manager
2. Click "Install Plugins"
3. Enter the repository URL: `https://github.com/DJJones66/NetworkEyes`
4. Click "Install Plugin"

### Manual Installation

1. Download the latest release from GitHub
2. Extract the plugin files
3. Use the BrainDrive plugin installer

## Configuration

The plugin supports the following configuration options:

- **Refresh Interval**: Set auto-refresh interval (default: 30 seconds)
- **Show Detailed Stats**: Toggle detailed network statistics display
- **Connection Timeout**: Configure network check timeouts

## Permissions

This plugin requires the following permissions:

- `network.read` - Read network status and connectivity information
- `storage.read` - Read plugin configuration and cached data
- `storage.write` - Save plugin settings and cache network data

## Module: Network Status Monitor

### Description
Real-time network connectivity monitoring dashboard that displays current network status, connection health, and service availability.

### Features
- Live network status indicators
- Connection quality metrics
- Service availability tracking
- Historical connectivity data
- Alert notifications for connection issues

### Layout
- **Minimum Size**: 3x2 grid units
- **Default Size**: 4x3 grid units
- **Resizable**: Yes

## Development

### Building the Plugin

```bash
npm install
npm run build
```

### Development Mode

```bash
npm run dev
```

## Version History

### v1.0.0
- Initial release
- Basic network monitoring functionality
- Real-time status dashboard
- Configurable refresh intervals

## Support

For issues, feature requests, or contributions:

- **GitHub Issues**: [https://github.com/DJJones66/NetworkEyes/issues](https://github.com/DJJones66/NetworkEyes/issues)
- **Repository**: [https://github.com/DJJones66/NetworkEyes](https://github.com/DJJones66/NetworkEyes)

## License

MIT License - see LICENSE file for details.

## Compatibility

- **BrainDrive Version**: 1.0.0+
- **Plugin API**: 1.0.0
- **Browser Support**: Modern browsers with ES2020 support

## Technical Details

- **Bundle Method**: Webpack Module Federation
- **Entry Point**: `dist/remoteEntry.js`
- **Framework**: React 18+
- **TypeScript**: Yes
- **Installation Type**: Remote (GitHub releases)